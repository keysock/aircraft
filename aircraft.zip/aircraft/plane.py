import sys
import pygame
from pygame.sprite import Sprite
pygame.init()



############################屏幕设置
screen=pygame.display.set_mode((800,600))
# screen=pygame.display.set_mode((0,0),pygame.FULLSCREEN)
screen_rect=screen.get_rect()
pygame.display.set_caption(("Alien Invasion"))
bg_color=(230,230,230)


##########################飞船设置
image=pygame.image.load('images/ship.bmp')
rect=image.get_rect()
rect.midbottom=screen_rect.midbottom

###############################子弹设置

bullet_speed = 1.0
bullet_width = 3
bullet_height = 15
bullet_color = (60, 60, 60)
bullet_rect=pygame.Rect(0,0,bullet_width,bullet_height)
bullet_rect.midtop=screen_rect.midtop

bullets=pygame.sprite.Group()

class Bullet(Sprite):
    def __init__(self):
        super().__init__()
        self.rect=pygame.Rect(0,0,bullet_width,bullet_height)
        self.rect.midtop=rect.midtop
        self.y=float(self.rect.y)

    def update(self):
        self.y -= bullet_speed
        self.rect.y -=  1

    def draw_bullet(self):
        pygame.draw.rect(screen,bullet_color,self.rect)

def rect_update():
    if moving_right and rect.right<=screen_rect.right:
        rect.x+=1
    if moving_left and rect.x>=0:
        rect.x-=1

moving_right=False
moving_left=False

def fire_bullet():
    new_bullet=Bullet()
    bullets.add(new_bullet)
while True:
    for event in pygame.event.get():
        if event.type==pygame.QUIT:
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key==pygame.K_RIGHT:
                moving_right=True
            elif event.key==pygame.K_LEFT:
                moving_left=True
            elif event.key==pygame.K_q:
                sys.exit()
            elif event.key==pygame.K_SPACE:
                fire_bullet()
        elif event.type == pygame.KEYUP:
            if event.key==pygame.K_RIGHT:
                moving_right=False
            elif event.key==pygame.K_LEFT:
                moving_left=False
    rect_update()
    bullets.update()
    screen.fill(bg_color)
    screen.blit(image,rect)
    for bullet in bullets.sprites():
        bullet.draw_bullet()
    pygame.display.flip()

