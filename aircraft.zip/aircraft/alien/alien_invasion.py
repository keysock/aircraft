import pygame
import sys
import random
import time

from settings import Setting
from ship import Ship
from game_stats import GameStats
from bullet import Bullet
from alien import Alien
from button import Button

from pygame.sprite import Sprite

class AlienInvasion:

    # 游戏初始化，获取屏幕、飞船、子弹的基本设置
    def __init__(self):
        pygame.init()
        self.settings=Setting()
        # self.screen = pygame.display.set_mode((800, 600))

        self.screen=pygame.display.set_mode((0,0),pygame.FULLSCREEN)
        self.settings.screen_width=self.screen.get_rect().width
        self.settings.screen_height=self.screen.get_rect().height

        pygame.display.set_caption('Alien Invasion')

        self.stats=GameStats(self)

        self.ship=Ship(self)

        self.bullet=pygame.sprite.Group()
        self.aliens=pygame.sprite.Group()

        self._create_fleet()
        self.play_button=Button(self,"play")

        self.createBullet=False
        self.game_ative=True

    def _create_fleet(self):
        num=random.randint(1,20)
        for i in range(0,num):
            alien=Alien(self)
            self.aliens.add(alien)

    def _update_aliens(self):
        self._check_fleet_edges()
        self.aliens.update(self.ship)
        if pygame.sprite.spritecollideany(self.ship,self.aliens):
            self._ship_hit()

    # def _check_aliens_bottom(self):


    def _check_fleet_edges(self):
        for alien in self.aliens.sprites().copy():
            if alien.check_edges():
                self.aliens.remove(alien)

    def _ship_hit(self):
        if self.stats.ship_left>0:
            self.stats.ship_left-=1
            self.aliens.empty()
            self.bullet.empty()

            self._create_fleet()
            self.ship.center_ship()
            time.sleep(2)
        else:
            self.stats.game_ative=False
            pygame.mouse.set_visible(True)

    # 游戏的主函数，通过调用该函数，可运行程序的所有函数
    def run_game(self):
        while True:
            self.check_events()
            if self.stats.game_ative:
                self.ship.update_ship()
                self.update_bullet()
                self.create_bullet()
                self._update_aliens()
            self.update_screen()


    # 检查键盘事件，并执行相应函数
    def check_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            elif event.type == pygame.KEYDOWN:
                self.check_keydown_events(event)
            elif event.type == pygame.KEYUP:
                self.check_keyup_events(event)
            elif event.type==pygame.MOUSEBUTTONDOWN:
                mouse_pos=pygame.mouse.get_pos()
                self._check_play_button(mouse_pos)

    def _check_play_button(self,mouse_pos):
        if self.play_button.rect.collidepoint(mouse_pos) and not self.stats.game_ative:
            self.stats.game_ative=True
            self.stats.reset_stats()

            self.aliens.empty()
            self.bullet.empty()

            self._create_fleet()
            self.ship.center_ship()

            pygame.mouse.set_visible(False)


    # 检查键盘按下事件
    def check_keydown_events(self,event):
        if event.key == pygame.K_RIGHT:
            self.ship.moving_right=True
        elif event.key == pygame.K_LEFT:
            self.ship.moving_left=True
        elif event.key == pygame.K_q:
            sys.exit()
        elif event.key == pygame.K_SPACE:
            self.createBullet=True

    # 键盘松开事件
    def check_keyup_events(self, event):
        if event.key == pygame.K_RIGHT:
            self.ship.moving_right = False
        elif event.key == pygame.K_LEFT:
            self.ship.moving_left = False
        elif event.key == pygame.K_SPACE:
            self.createBullet=False

    #进行子弹的移动，并检测子弹是否越过屏幕边界，如果越过则进行删除（防止子弹无用后占用内存）
    def update_bullet(self):
        self.bullet.update()
        for bullet in self.bullet.copy():
            if bullet.rect.bottom<=0:
                self.bullet.remove(bullet)
        self._check_bullet_alien_collisions()

    def _check_bullet_alien_collisions(self):
        collisions = pygame.sprite.groupcollide(self.bullet, self.aliens, True, True)
        if not self.aliens:
            # self.bullet.empty()
            self._create_fleet()

    # 创建子弹，以进行子弹射出
    def create_bullet(self):
        if self.createBullet:
            # new_bullet = Bullet(self)
            # self.bullet.add(new_bullet)
            if self.bullet:
                if self.ship.rect.y-self.bullet.sprites()[-1].y>25:
                    new_bullet=Bullet(self)
                    self.bullet.add(new_bullet)
            else:
                new_bullet = Bullet(self)
                self.bullet.add(new_bullet)


    # 屏幕更新。屏幕上所有可见内容，都是通过该函数加载出来的
    def update_screen(self):
        self.screen.fill(self.settings.screen_color)
        self.ship.blitmy()
        for bullet in self.bullet.sprites():
            bullet.draw_bullet()
        self.aliens.draw(self.screen)
        if not self.stats.game_ative:
            self.play_button.draw_button()
        pygame.display.flip()

if __name__=='__main__':
    ai=AlienInvasion()
    ai.run_game()