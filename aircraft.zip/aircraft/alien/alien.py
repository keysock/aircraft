import pygame
from pygame.sprite import Sprite
import random

class Alien(Sprite):
    def __init__(self,ai_game):
        super(Alien, self).__init__()
        self.screen=ai_game.screen
        self.screen_width=ai_game.settings.screen_width
        self.screen_height=ai_game.settings.screen_height
        self.settings=ai_game.settings

        self.image=pygame.image.load('../images/alien_01.png')
        self.rect=self.image.get_rect()

        self.rect.x=random.randint(0,self.screen_width)
        self.rect.y=random.randint(0,2)
        self.x=self.rect.x
        self.y=self.rect.y

        self.speed_x=(random.random()+0.1)/2
        self.speed_y=(random.random())/2+self.speed_x

    def update(self,ship):
        if self.x>ship.ship_x:
            # self.x-=self.settings.alien_speed
            self.x-=self.speed_x
        if self.x<ship.ship_x:
            # self.x+=self.settings.alien_speed
            self.x += self.speed_x
        self.rect.x=self.x
        self.y+=self.speed_y
        self.rect.y = self.y

    def check_edges(self):
        if self.rect.y>self.screen_height:
            return True