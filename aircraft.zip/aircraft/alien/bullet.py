import pygame
from pygame.sprite import Sprite

#玩家子弹
class Bullet(Sprite):
    def __init__(self,ai_game):
        super().__init__()
        self.ai_game=ai_game
        self.rect=pygame.Rect(
            0,0,ai_game.settings.bullet_width,ai_game.settings.bullet_height)       #子弹
        self.rect.midtop=ai_game.ship.rect.midtop   #子弹位置

        self.y=float(self.rect.y)   #记录子弹

    #子弹更新
    def update(self):
        self.y -= self.ai_game.settings.bullet_speed
        self.rect.y=self.y

    #绘制子弹
    def draw_bullet(self):
        pygame.draw.rect(
            self.ai_game.screen,self.ai_game.settings.bullet_color,self.rect)