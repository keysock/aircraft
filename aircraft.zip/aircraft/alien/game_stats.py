class GameStats:
    def __init__(self,aigame):
        self.settings=aigame.settings
        self.reset_stats()
        self.game_ative = False

    def reset_stats(self):
        self.ship_left=self.settings.ship_limit