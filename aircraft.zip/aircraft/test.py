for i in lista:
    if i % 2 == 0:
        lista.remove(i)