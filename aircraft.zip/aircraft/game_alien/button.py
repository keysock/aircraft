import pygame.draw

#按钮
class Button:
    def __init__(self,ai_game):
        self.screen=ai_game.screen  #屏幕

        #按钮信息。大小、位置、颜色、
        self.width=400
        self.height=200
        self.positon_X=self.screen.get_rect().width//2-self.width//2
        self.positon_Y=self.screen.get_rect().height//2-self.height//3
        self.color=(231,214,200)
        self.redius=100

        #文本信息。颜色、字体、大小
        self.text_color=(255,255,255)
        self.font=pygame.font.match_font('SimHei')
        self.font_main=pygame.font.Font(self.font,60)
        self.font_operation=pygame.font.Font(self.font,20)

        #文本
        self.msg='开始游戏'
        self.operation='W:上   S:下    A:左    D:右'
        self.exit='按 "空格" 进行攻击， 按 Q 退出游戏'

    #按钮绘制
    def blit(self):
        self.text_main()
        self.text_operation()
        self.text_exit()

    # “开始游戏”
    def text_main(self):
        self.img=self.font_main.render(self.msg,True,self.text_color)
        self.img_rect=self.img.get_rect()
        self.img_rect.center=self.screen.get_rect().center
        self.img_rect.y-=10
        self.screen.blit(self.img,self.img_rect)

    # 游戏操作
    def text_operation(self):
        img = self.font_operation.render(self.operation, True, self.text_color)
        img_rect = img.get_rect()
        img_rect.center = self.screen.get_rect().center
        img_rect.y += 50
        self.screen.blit(img, img_rect)

    # 游戏操作
    def text_exit(self):
        img = self.font_operation.render(self.exit, True, self.text_color)
        img_rect = img.get_rect()
        img_rect.center = self.screen.get_rect().center
        img_rect.y += 90
        self.screen.blit(img, img_rect)