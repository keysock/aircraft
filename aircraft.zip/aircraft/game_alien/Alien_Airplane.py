import sys
import pygame
import time

from plane_bullet.airplane import AirPlane
from plane_bullet.bullet import Bullet
from plane_bullet.alien import Alien
from plane_bullet.alien_bullets import AlBullet

from settings import Settings
from game_stats import GameStats
from button import Button
from scoreboard import Scoreboard


class Main:
    def __init__(self):
        pygame.init()
        self.setting = Settings()   #设置
        self.screen = pygame.display.set_mode((
            self.setting.screen_width,self.setting.screen_height
        ))

        self.airplane = AirPlane(self)  #飞船类
        self.stats = GameStats(self)    #游戏状态
        self.button = Button(self)  #按钮
        self.sb = Scoreboard(self)  #游戏得分

        self.bullets=pygame.sprite.Group()  #玩家子弹精灵
        self.aliens=pygame.sprite.Group()   #敌方飞船精灵
        self.al_bullets=pygame.sprite.Group()   #敌方子弹精灵



        self.pag=pygame.image.load('../images/aweq.jpeg')   #背景图片


        self.createBullet=False #玩家子弹连续发射
        self.clock = pygame.time.Clock()    #游戏帧数
        self.time,self.count=0,0    #飞船闪烁，击败数量

    #主程序
    def run_game(self):

        while True:
            self.clock.tick(1000)
            self.update_screen()    #屏幕更新
            self.bullet_manage()    #玩家子弹管理
            self.alien_bullet_manage()  #敌方子弹管理
            self._check_event()     #事件检测
            if self.stats.game_active:  #游戏状态。为false则敌方飞船和玩家飞船无法移动
                self.aliens_manage()
                self.airplane.airplane_moving()

    # 开始按钮检测
    def _check_play_button(self, mouse_pos):
        # 判断鼠标点击范围是否在“开始游戏”内，判断当前游戏是否已经开始
        if self.button.img_rect.collidepoint(mouse_pos) and not self.stats.game_active:
            self.stats.reset_stats()  # 重置游戏进度
            self.stats.game_active = True  # 激活游戏
            self.sb.prep_score()  # 重置游戏得分
            self.aliens.empty()  # 清空敌方飞船
            self.bullets.empty()  # 清空玩家子弹
            self.al_bullets.empty()  # 清空敌方子弹
            self.airplane.center_ship()  # 将玩家飞船重置到初始位置
            self.sb.prep_life()  # 重置玩家生命

    #事件检测
    def _check_event(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()  #整个程序结束运行
            elif event.type == pygame.KEYDOWN:
                self._check_keyDown(event)  #键盘按下
            elif event.type == pygame.KEYUP:
                self._check_keyUp(event)    #键盘松开
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos=pygame.mouse.get_pos()    #鼠标点击
                self._check_play_button(mouse_pos)

    #键盘松开事件
    def _check_keyUp(self,event):
        if event.key == pygame.K_a:
            self.airplane.moving_left=False
        elif event.key == pygame.K_d:
            self.airplane.moving_right=False
        elif event.key == pygame.K_w:
            self.airplane.moving_up=False
        elif event.key == pygame.K_s:
            self.airplane.moving_down=False
        elif event.key == pygame.K_SPACE:
                self.createBullet=False

    #键盘按下事件
    def _check_keyDown(self,event):
        if event.key == pygame.K_q:
            # 整个程序结束运行
            sys.exit()
        elif event.key == pygame.K_a:
            self.airplane.moving_left=True
        elif event.key == pygame.K_d:
            self.airplane.moving_right=True
        elif event.key == pygame.K_w:
            self.airplane.moving_up=True
        elif event.key == pygame.K_s:
            self.airplane.moving_down=True
        elif event.key == pygame.K_SPACE:
            if self.stats.game_active:
                self.createBullet=True

    #玩家子弹发射。控制发射频率
    def bullet_fire(self):
        #初始子弹
        if not self.bullets:
            bullet = Bullet(self)
            self.bullets.add(bullet)
        #发射频率
        elif self.bullets.sprites()[-1].rect.bottom < self.airplane.rect.top-40:
            bullet=Bullet(self)
            self.bullets.add(bullet)

    #玩家子弹管理
    def bullet_manage(self):
        #判断是否达到射击条件
        if self.createBullet:
            self.bullet_fire()
        bullets=self.bullets.copy()
        #删除超出屏幕范围的子弹
        for bullet in self.bullets:
            bullet.blit()
            bullet.update()
            if bullet.rect.bottom < 0:
                bullets.remove(bullet)
        self.bullets=bullets

    #敌方子弹管理。对敌方子弹进行更新，判断敌人子弹是否超出屏幕范围
    def alien_bullet_manage(self):
        bullets=self.al_bullets.copy()
        self.al_bullets.update()
        for bullet in self.al_bullets:
            bullet.blit()
            if bullet.rect.top>self.setting.screen_height:
                bullets.remove(bullet)
        self.al_bullets=bullets
        # print(len(self.al_bullets))

    #敌方子弹发射
    def alien_bullet_fire(self,alien):
        #初始子弹
        if not self.al_bullets:
            bullet = AlBullet(self, alien)
            self.al_bullets.add(bullet)
        #对子弹的发射频率做出限制
        if self.al_bullets.sprites()[-1].rect.top >alien.rect.bottom+50 and alien.rect.top>0:
            bullet=AlBullet(self,alien)
            self.al_bullets.add(bullet)

    #敌方数量检测
    def alien_fleet(self):
        #判断现有的敌人数量，如果敌人数量减少，则更新。对击败数进行统计
        if len(self.aliens)<self.setting.alien_number:
            alien=Alien(self)
            self.aliens.add(alien)
            self.count+=1
        #如果击败的数量达到初始数量，则增加敌方数量
        if self.count>=self.setting.alien_number:
            self.setting.increase_speed()
            self.count=0

    #敌人飞船管理
    def aliens_manage(self):
        self.alien_fleet()
        aliens=self.aliens.copy()
        self.aliens.update(self.airplane)
        for alien in self.aliens:
            if alien.rect.x not in range(-100,self.setting.screen_width) or alien.rect.y >self.setting.screen_height:
                aliens.remove(alien)
            self.alien_bullet_fire(alien)

        self.aliens=aliens

    #检测碰撞
    def check_collision(self):
        #玩家和敌方飞船、子弹的碰撞
        spri=pygame.sprite.spritecollideany(self.airplane,self.aliens)
        bul=pygame.sprite.spritecollideany(self.airplane,self.al_bullets)
        if (bul or spri) and time.time()-self.time>1.5:
            self.time=time.time()
            self.aliens.remove(spri)
            self.al_bullets.remove(bul)
            self.stats.ship_lift-=1
            self.sb.prep_life()
        if not self.stats.ship_lift:
            self.stats.game_active = False

        #玩家子弹和敌方飞船的碰撞
        collisions = pygame.sprite.groupcollide(self.bullets, self.aliens, True, True)
        if collisions:
            self.stats.score += self.setting.alien_point
            self.sb.prep_score()
            self.sb.check_high_score()
            self.sb.prep_life()

    #游戏屏幕更新
    def update_screen(self):
        pygame.display.flip()   #更新最新的屏幕
        self.screen.blit(self.pag,(-900,-500))  #背景图片
        self.aliens.draw(self.screen)
        if time.time() - self.time>0.2:
            self.airplane.blit()
        self.check_collision()
        self.sb.show_score()
        if not self.stats.game_active:  #开始按钮
            self.button.blit()

#
if __name__=='__main__':
    game=Main()
    game.run_game()