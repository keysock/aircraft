import pygame
from pygame.sprite import Sprite

from game_alien.settings import Settings

#敌方子弹
class AlBullet(Sprite):
    def __init__(self,ai_game,alien):
        super().__init__()
        self.setting=Settings()     #设置

        #屏幕
        self.screen=ai_game.screen
        self.screen_rect=self.screen.get_rect()

        #子弹
        self.rect=pygame.Rect(20,20,self.setting.bullet_width,self.setting.bullet_height)
        self.rect.midbottom=alien.rect.midbottom

        self.y=self.rect.y  #记录子弹位置

    #子弹更新
    def update(self):
        # print(self.rect.y)
        self.y += self.setting.alien_bullet_speed
        self.rect.y=self.y

    #子弹绘制
    def blit(self):
        pygame.draw.rect(self.screen,self.setting.alien_bullet_color,self.rect)