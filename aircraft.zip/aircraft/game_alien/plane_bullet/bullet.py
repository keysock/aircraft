import pygame
from pygame.sprite import Sprite

from game_alien.settings import Settings

#玩家子弹
class Bullet(Sprite):
    def __init__(self,ai_game):
        super().__init__()
        #设置
        self.setting=Settings()

        #屏幕
        self.screen=ai_game.screen
        self.screen_rect=self.screen.get_rect()

        # 玩家飞船
        self.air_rect=ai_game.airplane.rect

        #子弹
        self.rect=pygame.Rect(20,20,self.setting.bullet_width,self.setting.bullet_height)
        self.rect.midtop=ai_game.airplane.rect.midtop

        # 记录子弹
        self.y=self.rect.y

    #子弹更新
    def update(self):
        self.y -= self.setting.bullet_speed
        self.rect.y=self.y

    #子弹绘制
    def blit(self):
        pygame.draw.rect(self.screen,self.setting.bullet_color,self.rect)