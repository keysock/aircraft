import random
import pygame
from pygame.sprite import Sprite

from game_alien.settings import Settings

#敌方飞船
class Alien(Sprite):
    def __init__(self,ai_game):
        super().__init__()
        self.setting=Settings()

        # 屏幕
        self.screen=ai_game.screen
        self.screen_rect=self.screen.get_rect()

        # 飞船图片
        self.image=pygame.image.load('../images/alipl.png')
        self.rect=self.image.get_rect()

        # 飞船位置
        x=ai_game.setting.screen_width
        self.rect.x=random.randint(-x//2,x*2)
        self.rect.y=random.randint(-700,-100)

        #记录飞船位置
        self.x=self.rect.x
        self.y=self.rect.y

        #移动方向，最多改变一次
        self.moving_x=False
        self.change_moving=True

    #飞船移动
    def update(self,plane):
        if self.change_moving:
            if self.rect.x<plane.x:
                self.moving_x=True
            self.change_moving=False

        if self.moving_x:
            self.x += self.setting.alien_speedx
        else:
            self.x -= self.setting.alien_speedx

        self.y += self.setting.alien_speedy

        self.rect.y=self.y
        self.rect.x=self.x
        # print(self.rect.y)
