import pygame
from pygame.sprite import Sprite

from game_alien.settings import Settings

#玩家飞船
class AirPlane(Sprite):
    def __init__(self, ai_game):
        super().__init__()
        print('zxc')
        # 获取屏幕，屏幕大小
        self.screen = ai_game.screen
        self.screen_rect = self.screen.get_rect()

        # 导入飞船图片，获取图片的大小
        self.image = pygame.image.load('../images/plane01.png')
        self.rect = self.image.get_rect()

        # 使飞船的初始位置在屏幕底部的中心位置
        self.rect.midbottom = self.screen_rect.midbottom
        self.rect.y-=50

        #因为rect不能加减浮点数，使用先使用一个变量对飞船位置进行存储
        self.x = self.rect.x
        self.y = self.rect.y

        self.setting = Settings()   #设置

        #移动方向
        self.moving_right = False
        self.moving_left = False
        self.moving_up = False
        self.moving_down = False

    #控制飞船的移动
    def airplane_moving(self):
        if self.moving_right and self.rect.right < self.screen_rect.width:
            self.x += self.setting.airplane_speed

        if self.moving_left and self.rect.left > 0:
            self.x -= self.setting.airplane_speed

        if self.moving_down and self.rect.bottom<self.screen_rect.height:
            self.y += self.setting.airplane_speed

        if self.moving_up and self.rect.top>0:
            self.y -= self.setting.airplane_speed

        self.rect.y = self.y
        self.rect.x = self.x

    #飞船位置
    def center_ship(self):
        self.rect.midbottom = self.screen_rect.midbottom
        self.rect.y-=50
        self.x=float(self.rect.x)
        self.y=float(self.rect.y)

    def blit(self):
        # 对飞船进行绘制
        self.screen.blit(self.image, self.rect)
