
#游戏数据
class Settings:
    def __init__(self):
        #屏幕信息
        self.screen_width=1000
        self.screen_height=700
        self.screen_color=(230,230,230)

        #玩家飞船信息
        self.airplane_speed=1.5
        self.airplane_limit=3

        #玩家子弹信息
        self.bullet_width=5
        self.bullet_height=15
        self.bullet_color=(97,189,254)
        self.bullet_speed=1.5

        #敌方子弹信息
        self.alien_bullet_color=(250,6,52)
        self.alien_bullet_speed=1

        #敌方飞船信息
        self.alien_speedy=0.2
        self.alien_speedx=0.1
        self.alien_number=10
        self.alien_point=50

    #游戏难度设置
    def increase_speed(self):
        self.alien_bullet_speed+=0.1
        self.airplane_speed+=0.2