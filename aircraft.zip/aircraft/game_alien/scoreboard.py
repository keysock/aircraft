import pygame.font

from game_alien.plane_bullet.airplane import AirPlane

#游戏得分，以及飞船生命显示
class Scoreboard:
    def __init__(self,ai_game):
        self.ai_game=ai_game
        self.screen=ai_game.screen      #屏幕
        self.screen_rect=self.screen.get_rect()

        self.settings=ai_game.setting       #设置
        self.stats=ai_game.stats        #游戏信息

        #得分信息
        self.text_color=(200,170,131)
        self.font=pygame.font.SysFont(None,48)

        #屏幕上初始显示
        self.prep_score()
        self.prep_high_score()
        self.prep_ships()
        self.prep_life()

    #最高得分
    def prep_high_score(self):
        high_score=round(self.stats.high_score,-1)
        high_score_str='{:,}'.format(high_score)
        self.high_score_image=self.font.render(high_score_str,True,self.text_color)

        self.high_score_rect=self.high_score_image.get_rect()
        self.high_score_rect.centerx=self.screen_rect.centerx
        self.high_score_rect.top=self.score_rect.top

    #检测最高得分
    def check_high_score(self):
        if self.stats.score>self.stats.high_score:
            self.stats.high_score=self.stats.score
            self.prep_high_score()

    #当前得分
    def prep_score(self):
        score_str=str(self.stats.score)
        rounded_score=round(self.stats.score,-1)
        score_str="{:,}".format(rounded_score)
        self.score_image=self.font.render(score_str,True,self.text_color)

        self.score_rect=self.score_image.get_rect()
        self.score_rect.right=self.screen_rect.right-20
        self.score_rect.top=30

    #右上角飞船
    def prep_ships(self):
        self.ship=AirPlane(self.ai_game)
        self.ship.rect.x=10
        self.ship.rect.y=10

    #右上角飞船生命
    def prep_life(self):
        score_str = 'X  '+str(self.stats.ship_lift)
        self.life = self.font.render(score_str, True, self.text_color)

        self.life_rect = self.score_image.get_rect()
        self.life_rect.left = self.screen_rect.left + 130
        self.life_rect.top = 30

    # 显示在屏幕上
    def show_score(self):
        self.screen.blit(self.score_image, self.score_rect)
        self.screen.blit(self.high_score_image, self.high_score_rect)
        self.ship.blit()
        self.screen.blit(self.life, self.life_rect)
