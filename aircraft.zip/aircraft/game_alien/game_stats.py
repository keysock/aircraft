

#游戏信息
class GameStats:
    def __init__(self,ai_game):
        self.setting=ai_game.setting    #设置
        self.reset_stats()      #重置

        self.game_active=False  #游戏状态
        self.score=0    #当前得分
        self.high_score=0   #最高得分

    #重置游戏
    def reset_stats(self):
        self.ship_lift=self.setting.airplane_limit  #生命值
        self.score=0
        self.setting.alien_bullet_speed=1   #敌方子弹速度
        self.setting.airplane_speed=1.5     #飞船速度